The matrix folders are not included.

To execute each .py, no parameters are needed, because there are default settings. If you want to change it:

- C3.py/C4.py [n] where n is the dimension desired.

- C5.py/C6.py [folderName] where folderName can be "optpr1" or "optpr2"