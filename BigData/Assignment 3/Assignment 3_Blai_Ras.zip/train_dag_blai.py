#Author: Blai Ras
#Subject: Big Data
#Degree: MSc in Data Science
#University: Universitat de Barcelona

#Assignment 3: Airflow


#Imports
#Airflow Imports
import airflow
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.models import Variable

#For handeling when the DAG is executed
from datetime import datetime, timedelta

#To get the stored CSV files without boto3
import requests
#Dataframe handeling
import pandas as pd
#Model saving
import pickle

#Training
from sklearn.utils import shuffle
from sklearn.linear_model import LogisticRegression


#Get the Airflow Variable, formated as JSON, which store:
#1. Training files locations
#2. Predict file location
#3. Saving file location
#4. Name for the model we train & load
#5. Name for the train set
#6. Name for the final prediction file
#7. Number of samples of train set 
dag_config = Variable.get("config_variables",deserialize_json=True)


# Those variable are set here because they're used in two different functions.
MODEL_NAME = dag_config["model_name"]
PREDICT_URL = dag_config["predict_data"]
SAVE_LOCATION = dag_config["store_path"]
TRAIN_NAME = dag_config["train_name"]

#Default arguments for the DAG instantiation
default_args = {
    'owner': 'Blai Ras',
    #For example, set the DAG execution start 1 day ago
    'start_date': airflow.utils.dates.days_ago(1),
    #No end-date in theory
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    # If a task fails, retry it once after waiting
    # at least 5 minutes
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

#T1: download all training csv from s3 bucket and store locally.
def download_train():
    #Get airflow variable that stores where's the training data
    DATA_URL = dag_config["train_data"]

    #With Requests.get I get an string that splitted by 'endline' gives me each URL where train data is stored
    urls = requests.get(DATA_URL).text.split("\n")

    #Init train df
    train = pd.DataFrame()
    for url in urls:
        #Read each CSV and store it as one, with the proper name
        train = pd.concat([train,pd.read_csv(url)])

    #Store the csv
    train.to_csv(SAVE_LOCATION+TRAIN_NAME,index=None)


#T2: Read all the downloaded csv and train the model and finally save the model locally.
def train():
    #Read the train data
    data = pd.read_csv(SAVE_LOCATION+TRAIN_NAME)
    
    #Separate target variable
    X = data.drop(["Species"],axis=1).values
    y = data[["Species"]]
    X_new, y_new = shuffle(X, y, random_state=0)

    #With the n_samples variable I split train & test
    n_samples_train = int(dag_config["n_samples"])

    X_train = X_new[:n_samples_train, :]
    y_train = y_new[:n_samples_train]

    X_test = X_new[n_samples_train:, :]
    y_test = y_new[n_samples_train:]

    #Fit logistic regression model
    clf = LogisticRegression(max_iter=150)
    clf.fit(X_train, y_train)

    #Save the model with the specified name
    with open(MODEL_NAME, 'wb') as f:
        pickle.dump(clf, f)

#T3: Download prediction.csv from S3 save it locally
def download_predict():
    #Get the csv file from the stored URL & save it.
    pd.read_csv(PREDICT_URL).to_csv(SAVE_LOCATION+PREDICT_URL.split("/")[-1],index=None)

#T4: Load the local model and read the downloaded prediction CSV.
#Save a csv with prediction of Species for each input row in prediction.csv
def predict():
    #Load the model
    with open(SAVE_LOCATION+MODEL_NAME, 'rb') as f:
        clf_loaded = pickle.load(f)

    #Load the final prediction file name
    PREDICT_NAME = dag_config["predict_name"]

    #Create a new dataframe which contains the final predictions
    pd.DataFrame({"Predicted Specie":clf_loaded.predict(
        pd.read_csv(PREDICT_URL.split("/")[-1]))}
    ).to_csv(SAVE_LOCATION+PREDICT_NAME,index=None)

    #Successful message
    print("Succesfully trained & loaded the model.\n Successfully predicted the species:\n", pd.read_csv(SAVE_LOCATION+PREDICT_NAME))



# DAG Instance
with DAG("train_dag_blai", default_args = default_args,
    schedule_interval="0 20 * * MON", catchup=False) as dag:
    
    #Tasks
    #T1
    downloadTrain = PythonOperator(task_id="download_train",python_callable=download_train)
    #T2
    trainingModel = PythonOperator(task_id="training_model",python_callable=train)
    #T3
    downloadPredict = PythonOperator(task_id="download_predict",python_callable=download_predict)
    #T4
    predict_task = PythonOperator(task_id="predict",python_callable=predict)

    #Task relationship: T1 -> T2 -> T4 & T3 -> T4
    downloadTrain >> trainingModel >> predict_task
    downloadPredict >> predict_task


