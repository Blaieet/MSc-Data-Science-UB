Hi Rohit:

Find in this folder:

1. My DAG code in Python
2. Screenshot of the final DAG
3. Screenshot of the files created after the execution (in my case, inside the worker container of Docker)
4. Log's of one successful execution. I recommend looking at the last one since it's the only one with a print() statement.

Regards,

Blai Ras